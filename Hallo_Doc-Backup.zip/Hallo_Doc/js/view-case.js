$(document).ready(function () {
        $("#EditBtn").click(function () {
          $("#this").attr("disabled", true);
          console.log("first");
        });

        $("#SaveBtn").click(function () {
          $("#this").attr("disabled", false);
          console.log("second");
        });
      });